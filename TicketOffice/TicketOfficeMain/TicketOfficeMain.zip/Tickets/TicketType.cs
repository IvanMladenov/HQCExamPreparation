﻿namespace TicketOfficeMain.Tickets
{
    public enum TicketType
    {
        Bus, 

        Flight, 

        Train
    }
}