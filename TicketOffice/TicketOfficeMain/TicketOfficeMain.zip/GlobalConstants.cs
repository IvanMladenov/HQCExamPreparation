﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TicketOfficeMain
{
    public class GlobalConstants
    {
        public const string FlightCreated = "Flight created";
        public const string DuplicatedFlight = "Duplicated flight";
        public const string FlightDeleted = "Flight deleted";
        public const string FlightDoesNotExist = "Flight does not exist";

        public const string TrainCreated = "Train created";
        public const string DuplicatedTrain = "Duplicated train";
        public const string TrainDeleted = "Train deleted";
        public const string TrainDoesNotExist = "Train does not exist";

        public const string BusCreated = "Bus created";
        public const string DuplicatedBus = "Duplicated bus";
        public const string BusDeleted = "Bus deleted";
        public const string BusDoesNotExist = "Bus does not exist";

        public const string DateTimeFormat = "dd.MM.yyyy HH:mm";

        public const string Duplicated = "Duplicated ";

        public const string Created = "created";

        public const string Deleted = "deleted";

        public const string NoMatches = "No matches";

    }
}
